package pl.gustaw.hmitoggle;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HmiToggleMod implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("hmi-toggle");

    // Flaga kontrolujaca czy HMI jest aktywne - sprawdzana w mixinie
    public static boolean HMI_ENABLED = true;

    private KeyMapping toggleKey;

    @Override
    public void onInitializeClient() {
        // Klawisz 9 (GLFW_KEY_9 = 57)
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.hmi_toggle.toggle",
            GLFW.GLFW_KEY_9,
            "key.categories.hmi_toggle"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                toggleHmi(client);
            }
        });

        LOGGER.info("[HMI-Toggle] Zaladowano! Klawisz 9 = toggle Hold My Items.");
    }

    private void toggleHmi(Minecraft client) {
        HMI_ENABLED = !HMI_ENABLED;

        String status = HMI_ENABLED ? "§aWŁĄCZONY" : "§cWYŁĄCZONY";
        LOGGER.info("[HMI-Toggle] Hold My Items: {}", HMI_ENABLED ? "ON" : "OFF");

        if (client.player != null) {
            client.player.displayClientMessage(
                Component.literal("§e[HMI] §fHold My Items: " + status),
                true // action bar - nad hotbarem
            );
        }
    }
}
