package pl.gustaw.hmitoggle.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.gustaw.hmitoggle.HmiToggleMod;

/**
 * Mixin na com.holdmylua.source.lua_runtime.LuaScriptCache
 *
 * Metoda execute() uruchamia skrypty Lua odpowiedzialne za animacje itemów.
 * Gdy HMI_ENABLED = false, anulujemy wywołanie → mod jest wizualnie wyłączony.
 *
 * targets jako String zamiast .class bo HMI nie jest compile-time dependency.
 */
@Mixin(targets = "com.holdmylua.source.lua_runtime.LuaScriptCache", remap = false)
public class LuaScriptCacheMixin {

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true, remap = false)
    private void hmiToggle_cancelExecute(CallbackInfo ci) {
        if (!HmiToggleMod.HMI_ENABLED) {
            ci.cancel();
        }
    }
}
